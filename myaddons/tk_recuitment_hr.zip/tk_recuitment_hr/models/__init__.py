# -*- coding: utf-8 -*-

from . import models
from . import group_criterias
from . import criterias
from . import set_criterias
from . import review
from . import job
from . import hr_job_inherit
from . import hr_applicant_inherit